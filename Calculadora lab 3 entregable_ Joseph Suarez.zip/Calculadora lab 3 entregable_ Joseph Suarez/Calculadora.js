
let num1;
let num2;
let operacion;


function realizarOperacion(num1, num2, operacion) {
  if (operacion === "suma") {
    return num1 + num2;
  } else if (operacion === "resta") {
    return num1 - num2;
  } else if (operacion === "multiplicacion") {
    return num1 * num2;
  } else if (operacion === "division") {
    if (num2 === 0) {
      return "Error: no se puede dividir por cero";
    }
    return num1 / num2;
  } else {
    return "Error: operación no válida";
  }
}


let continuar = true;

while (continuar) {
  // Pedir datos al usuario
  num1 = parseFloat(prompt("Ingrese el primer número:"));
  num2 = parseFloat(prompt("Ingrese el segundo número:"));
  operacion = prompt("Ingrese la operación (suma, resta, multiplicacion, division) o escriba 'salir' para finalizar:");

  // Si el usuario quiere salir
  if (operacion === "salir") {
    alert("Gracias por usar la calculadora. ¡Hasta luego!");
    continuar = false;
    break;
  }

  // Realizar la operación
  let resultado = realizarOperacion(num1, num2, operacion);

  // Mostrar resultado
  alert("El resultado es: " + resultado);

  // Preguntar si desea otra operación
  let otra = prompt("¿Desea realizar otra operación? (si/no)");
  if (otra.toLowerCase() !== "si") {
    continuar = false;
    alert("Gracias por usar la calculadora. ¡Hasta luego!");
  }
}
